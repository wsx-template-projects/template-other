<!--
   demolist
-->
<template>
    <div class="page">
        demo-list
        <div class="main">
            <img-upload v-model="imgList" />
            <wsx-tips txt="tips显示" />
            <wsx-tips txt="tips--------显示" />
        </div>
    </div>
</template>

<script>
import wsxTips from './wsx-tips'
import http from '@/utils/http'
import imgUpload from '@/components/imgUpload'
import tools from '@/utils/tools'
export default {
    name: '',
    data() {
        return {
            imgList: [],
            timer1: null,
            timer2: null
        }
    },
    computed: {
        // throttleFunc () {
        //     return tools.throttle('目标函数','时间间隔')
        //     // 调用方式 ==》 this.throttleFunc()
        // }
    },
    components: { wsxTips, imgUpload },
    created() {
        // const obj = {
        //     list: [1,2] // 手动设置 list: null
        // }
        // const {list = []} = obj
    },
    mounted() {
        let data = {
            id: 1,

            children: [
                { id: 11 },
                {
                    id: 12,

                    children: [
                        {
                            id: 111,

                            children: [
                                {
                                    id: 1111
                                }
                            ]
                        },
                        {
                            id: 112
                        }
                    ]
                }
            ]
        }
        let list = this.deepTree(data.children, 1)
        console.log('-list-', list)
    },
    methods: {
        deepTree(list, leval = 1) {
            let result = []
            let currLeval = leval
            list.forEach(item => {
                let temp = { ...item }
                temp.leval = leval
                console.log('-item-', temp, temp.children)
                if (temp.children && temp.children.length > 0) {
                    temp.children = this.deepTree(temp.children, currLeval + 1)
                }
                result.push(temp)
            })
            return result
        }
    }
}
</script>
<style lang="less" scoped>
//@import url(); 引入公共css类
</style>
