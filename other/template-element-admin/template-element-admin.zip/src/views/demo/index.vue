<!--
   demo管理,路由出口
-->
<template>
    <div class="">
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    name: '',
    data() {
        return {}
    },
    computed: {},
    components: {},
    created() {},
    mounted() {},
    methods: {}
}
</script>
<style lang="less" scoped>
//@import url(); 引入公共css类
</style>
