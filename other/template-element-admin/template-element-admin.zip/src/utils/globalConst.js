/*
 * @Author: wangshengxian
 * @Date: 2021-01-07 17:52:18
 * @LastEditors: wangshengxian
 * @LastEditTime: 2021-01-07 18:07:47
 * @Desc: 全局常量
 */

/**
 * 图片的访问域名
 */
export const imgHeadUrl = 'http://trex.oss-accelerate.aliyuncs.com'
