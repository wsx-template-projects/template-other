// 全局常量

/**
 *图片/视频的访问域名
 */
export const resourceUrl = 'http://video.whkuaiyu.com'

/**
 * 网宿云存储的上传域名
 */
export const wcsUploadUrl = 'http://videopush.85tstss.com'
